class CountryViewModel{
  List<String> country = [
    "india",
    "afghanistan",
    "pakistan",
    "newzeland",
    "America",
    "china",
    "england",
    "sauth africa",
    "srilanka"
    "africa"
  ];
}