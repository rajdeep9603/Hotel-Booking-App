import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ColorRes{
  static const Color white1 = Color(0xFFF7F7F7);
  static const Color green1 = Color(0xFF4FBE9F);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color grey = Colors.grey;
  static const Color grey2 = Color(0xFFF7F7F7);
  static const Color greenog = Color(0xFF4FBE9F);
  static const Color bgcolor = Color(0xFFF7F7F7);
  static const Color whitexcreate = Color(0xFFFFFFFF);
  static const Color facebook = Color(0xFF3C5799);
  static const Color twitter = Color(0xFF05A9F0);

}