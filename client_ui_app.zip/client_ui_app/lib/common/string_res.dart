class StringRes{
  static const String name = "hello";
  static const String exploretitle = "Explore";
}